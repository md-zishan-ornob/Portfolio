// Portfolio Section

$(document).ready(function () {


    let $btns = $('#portfolio .button-group button');


    $btns.click(function (e) {

        $('#portfolio .button-group button').removeClass('active');
        e.target.classList.add('active');

        let selector = $(e.target).attr('data-filter');
        $('#portfolio .grid').isotope({
            filter: selector
        });

        return false;
    })

    $('#portfolio .button-group #btn1').trigger('click');

    $('#portfolio .grid .test-popup-link').magnificPopup({
        type: 'image',
        gallery: { enabled: true }
    });

// End of Portfolio Section
    // Owl-carousel

    $('#testimonial .owl-carousel').owlCarousel({
        loop: true,
        autoplay: true,
        dots: true,
        responsive: {
            0: {
                items: 1
            },
            560: {
                items: 2
            }
        }
    })
// End of Owl Carousel